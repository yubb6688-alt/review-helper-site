# 知评 · 插件试用站

免费静态演示页面与浏览器扩展下载。

- Mac / Windows：使用相同 ZIP，在电脑 Chrome 中解压加载。
- 插件为本地关键词规则试用版，尚未接入 AI；不提供整店抓取。
- 店铺搜索为虚构数据演示，不对应真实店铺。
- 插件尚未完成真实淘宝 / 天猫页面和两种系统的完整验收。

## 发布

GitHub 仓库 Settings → Pages → Deploy from a branch，选择 main 分支与 / (root)。
无需构建，入口是 index.html；图片和下载链接使用相对路径。
